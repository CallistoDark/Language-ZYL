Installing Instructions:
Just unzip the files and put them into in the same folder.